Basic asteroids clone based on the bitflyer game
################################################

This is a very simplified version of the amazing bitflyer game created by Steve Stagg
(https://github.com/stestagg/bitflyer)

Credit to him also for the splash and game over screens

Installation
=============
1. Flash an empty file with mu
2. Use the file copy functionality of mu to copy the following files: main.py, splash, game_over, ssd1306.py, ssd1306_stamp.py and ssd1306_bitmap.py
3. Reset the micro:bit


   .. image:: bitflyer.PNG
      :width: 100%
      :align: center
