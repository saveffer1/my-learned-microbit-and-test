from ssd1306_bitmap import *

show_bitmap("microbit_logo")